---
name: Regression Report
about: Let us know if something that'd been working has broke
---

## What happened before?




## What happens now?




## Last stable commit / Since when?




## Steps to reproduce

[//]: # (Any or all of the following:)
[//]: # (* Host system configuration: OS, Docker & friends' versions etc.)
[//]: # (* Project generation options)
[//]: # (* Logs)


