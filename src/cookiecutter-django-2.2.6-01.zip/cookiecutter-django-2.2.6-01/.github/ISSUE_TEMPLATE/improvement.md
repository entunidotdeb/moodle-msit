---
name: Improvement Suggestion
about: Let us know how we could improve
---

## Description

[//]: # (What's it you're proposing? How should it be implemented?)




## Rationale

[//]: # (Why should this feature be implemented?)




## Use case(s) / visualization(s)

[//]: # ("Better to see something once than to hear about it a thousand times.")


